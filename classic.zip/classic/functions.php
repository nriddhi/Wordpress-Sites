<?php


   //add theme support
   
   add_theme_support('html5', array('search-form'));



   // For Menu register

              add_action('init', 'wpj_register_menu');
	function wpj_register_menu() {
	if (function_exists('register_nav_menu')) 
	{
	register_nav_menu( 'wpj-main-menu', __( 'MainMenu', 'Riddhi' ) );
	}    }
	function wpj_default_menu() {
	echo '<ul id="tiny">';
	if ('page' != get_option('show_on_front')) 
	{    echo '<li><a href="'. home_url() . '/">Home</a></li>';
	}       wp_list_pages('title_li=');
		echo '</ul>';
		
	}
	
	
	
/*   Widget For Submenu  */
              function Redesign_Right_Sidebar() {
              register_sidebar( array(
		'name' => __( 'sub-menu','Redesign' ),
                              'id' => 'sub-menu',
		'description' => __( 'This widget will display on right sidebar blog Archives', 'Redesign' ),
		'before_widget' => '<div class="popular-posts-area">',
		'after_widget' => '</div>',
		'before_title' => '<h2>',
		'after_title' => '</h2>',
	) );}
               add_action('widgets_init', 'Redesign_Right_Sidebar');
	
	
	
          /*   Widget For Submenu  */
              function Redesign_Right_Sidebar2() {
              register_sidebar( array(
		'name' => __( 'recent-post','Redesign' ),
                              'id' => 'recent-post',
		'description' => __( 'This widget will display on right sidebar blog Archives', 'Redesign' ),
		'before_widget' => '<div class="popular-posts-area">',
		'after_widget' => '</div>',
		'before_title' => '<h2>',
		'after_title' => '</h2>',
	) );}
               add_action('widgets_init', 'Redesign_Right_Sidebar2');
	
	
	
	 /*   Widget For Submenu  */
              function Redesign_Right_Sidebar3() {
              register_sidebar( array(
		'name' => __( 'flicker-images','Redesign' ),
                              'id' => 'flicker-images',
		'description' => __( 'This widget will display on right sidebar blog Archives', 'Redesign' ),
		'before_widget' => '<div class="popular-posts-area">',
		'after_widget' => '</div>',
		'before_title' => '<h2>',
		'after_title' => '</h2>',
	) );}
               add_action('widgets_init', 'Redesign_Right_Sidebar3');
	
	
	
     //feature image
     
     add_theme_support( 'post-thumbnails', array( 'post' ) );
     set_post_thumbnail_size( 200, 200, true );
     add_image_size( 'post-image', 625, 350, true );
     
     //For Pagination
     function pagination($pages = '', $range = 3)
{    $showitems = ($range * 2)+1;
     global $paged;
     if(empty($paged)) $paged = 1;
     if($pages == '')
     {   global $wp_query;
        $pages = $wp_query->max_num_pages;
         if(!$pages)
         {  $pages = 1;
          }
  } 
     if(1 != $pages)
     {
         echo "<div class=\"pagination\"><span>Page ".$paged." of ".$pages."</span>";
         if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<a href='".get_pagenum_link(1)."'>&laquo; First</a>";
         if($paged > 1 && $showitems < $pages) echo "<a href='".get_pagenum_link($paged - 1)."'>&lsaquo; Previous</a>";
         for ($i=1; $i <= $pages; $i++)
         {             if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems ))
             {
      echo ($paged == $i)? "<span class=\"current\">".$i."</span>":"<a href='".get_pagenum_link($i)."' class=\"inactive\">".$i."</a>";   }
         }
  if ($paged < $pages && $showitems < $pages) echo "<a href=\"".get_pagenum_link($paged + 1)."\">Next &rsaquo;</a>"; 
         if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($pages)."'>Last &raquo;</a>";
         echo "</div>\n";
     }
}

//for comment options

 function theme_scripts() {
     if ( is_singular() && comments_open() && get_option( 'thread_comments' ) )
 {		wp_enqueue_script( 'comment-reply' ); }	
  }
add_action( 'wp_enqueue_scripts', 'theme_scripts' );


/* Register Custom Post Types********************************************/

	add_action( 'init', 'create_post_type' );
	function create_post_type() {
               register_post_type( 'testimonial',
	array(
	'labels' => array(
	'name' => __( 'Testimonial' ),
	'singular_name' => __( 'Testimonial' ),
	'add_new' => __( 'Add New' ),
	'add_new_item' => __( 'Add New Testimonial' ),
	'edit_item' => __( 'Edit Testimonial' ),
	'new_item' => __( 'New Testimonial' ),
	'view_item' => __( 'View Testimonial' ),
	'not_found' => __( 'Sorry, we couldn\'t find the Testimonial you are looking for.' )
				),
				
	'public' => true,
	'orderby' => 'rand',
               'publicly_queryable' => false,
	'exclude_from_search' => true,
	'menu_position' => 14,
	'has_archive' => false,
	'hierarchical' => false, 
	'capability_type' => 'page',
               'rewrite' => array( 'slug' => 'testimonial' ),
	'supports' => array( 'title', 'editor', 'custom-fields' )
			)
		);
	}












?>
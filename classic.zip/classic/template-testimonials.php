
<?php

/*

Template Name: Testmonials template

*/

 get_header();  ?>


  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
             
          <?php query_posts ('post_type=testimonial & post_status=publish & posts_per_page = 1 & paged ='. get_query_var('paged')); ?>
          
          <?php if(have_posts()) : ?>
   
         <?php while(have_posts())  : the_post(); ?>
         
          <div class="testimonial">
            
            <?php the_content();  ?>
            
          </div>
          
          <div class="client-name">
          
          <?php the_title();  ?>
          
          </div>
          
  
    <?php endwhile; ?>
    <?php else : ?>
     <?php get_template_part('404') ?>
    <?php endif; ?>	
          
          	

        </div>
        
      </div>
      
      
      <?php get_sidebar(); ?>
      
      
      <div class="clr"></div>
    </div>
  </div>
  
  <?php get_template_part('footer-top');  ?>
  
 <?php get_footer(); ?>
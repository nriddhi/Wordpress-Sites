<div class="sidebar">
        <div class="searchform">
		
          <?php get_search_form(); ?>
		  
        </div>
        <div class="gadget">
          <div class="clr"></div>
          <ul class="sb_menu">
             
             <?php if ( ! dynamic_sidebar( 'sub-menu' ) ) : ?>   
             <?php  endif; ?>

          </ul>
        </div>
        

        <div class="gadget">
          <div class="clr"></div>
          <ul class="ex_menu">
            
            <?php dynamic_sidebar('recent-post');  ?>
            
          </ul>
        </div>
        
        <div class="gadget">
        
        <h2> Testimonials  </h2>
        
          <div class="clr"></div>
          
          
         <?php query_posts('offset=0&orderby=rand'); ?> 

<?php query_posts('post_type=testimonial&post_status=publish&posts_per_page=1&offset=0&orderby=rand&orderby=rand&paged='. get_query_var('paged')); ?>
         
     
          <?php if(have_posts()) : ?>
   
         <?php while(have_posts())  : the_post(); ?>
         
          <div class="testimonial">
            
            <?php the_content();  ?>
            
          </div>
          
          <div class="client-name">
          
          <?php the_title();  ?>
          
          </div>
		  		  
				  
<a href="">View all</a>
          
  
    <?php endwhile; ?>
    <?php else : ?>
     <?php get_template_part('404') ?>
    <?php endif; ?>	
          
          
          
        </div>
        
        
        
      </div>
<form id="formsearch" name="formsearch" method="get" action="<?php echo home_url( '/' ); ?>">
            
            <span>
            <input name="s" class="editbox_search" 
            id="editbox_search" maxlength="80"  
            placeholder="<?php echo esc_attr_x( 'Search …', 'placeholder' ) ?>" 
            type="search" />
            </span>
            <input 
            src="<?php echo get_template_directory_uri(); ?>/images/search_btn.gif" 
            class="button_search" 
            value="<?php echo esc_attr_x( 'Search', 'submit button' ) ?>" 
            type="image" />
 </form>
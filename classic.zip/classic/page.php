
<?php get_header();  ?>


  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
            <?php if(have_posts()) : ?>
   <?php while(have_posts())  : the_post(); ?>
    <h2> <?php  the_title();   ?>  </h2>
    <?php the_content(); ?>
  <?php comments_template( '', true ); ?>  
    <?php endwhile; ?>
    <?php else : ?>
     <?php get_template_part('404') ?>
    <?php endif; ?>	

        </div>
        
      </div>
      
      
      <?php get_sidebar(); ?>
      
      
      <div class="clr"></div>
    </div>
  </div>
  
  <?php get_template_part('footer-top');  ?>
  
 <?php get_footer(); ?>
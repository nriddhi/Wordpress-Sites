
<?php get_header();  ?>


  <div class="content">
    <div class="content_resize">
      
     <div class="mainbar">
        <div class="article">
        
          <?php if(have_posts()) : ?>
          
          <h2>  Search Result for : "<?php the_search_query();   ?>"   </h2>
   
         <?php while(have_posts())  : the_post(); ?>

          <h2><a href="<?php the_permalink();  ?>"> <?php the_title(); ?> </a></h2>
          <div class="clr"></div>
          <p><span class="date">Date: <a href="#"><?php the_time('M d, Y') ?></a></span>

          &nbsp;|&nbsp; Posted by <a href="#"><?php the_author_posts_link()?></a> &nbsp;|&nbsp;
         
         Filed under <a href="#"><?php the_category(', '); ?> </a></p>
          
          <?php the_post_thumbnail('post-image', array('class' => 'post-thumb')); ?>
          
          <p>  <?php the_excerpt('250'); ?> </p>
          
          <p class="spec"><a href="#" class="com"><span><?php comments_number( 'no responses', '1 response', '% responses' ); ?></span></a> 
          <a href="<?php the_permalink();  ?>" class="rm">Read more &raquo;</a>
          </p>
  
    <?php endwhile; ?>
    <?php else : ?>
     <?php get_template_part('404') ?>
    <?php endif; ?>	

        
        </div>
        
        <p class="pages"><?php if (function_exists("pagination")) {
    pagination($additional_loop->max_num_pages);
} ?>     
</p>
      </div>
      
      <?php get_sidebar(); ?>
      
      
      <div class="clr"></div>
    </div>
  </div>
  
  <?php get_template_part('footer-top');  ?>
  
 <?php get_footer(); ?>
 <div class="single_sidebar fix">
<?php query_posts('post_type=testimonial&post_status=publish&posts_per_page=1&paged='. get_query_var('paged')); ?>
						
<?php if(have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>        

<div class="single_testimonial fix">
<div class="client_comment fix">
<?php the_content(); ?>
</div>
<div class="client_name fix">
<?php the_title(); ?>
							</div>
</div>

<?php endwhile; ?>    
<?php endif; ?>
													
<a class="view-all" href="">View All Testimonial</a>
</div>
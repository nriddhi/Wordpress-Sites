
<?php get_header();  ?>


  <div class="content">
    <div class="content_resize">
      
      <?php get_template_part('post-loop') ?>
      
      <?php get_sidebar(); ?>
      
      
      <div class="clr"></div>
    </div>
  </div>
  
  <?php get_template_part('footer-top');  ?>
  
 <?php get_footer(); ?>